# RAG Test — Système RAG avec Ollama & ChromaDB

Un système **RAG** (*Retrieval-Augmented Generation*) local, sans clé API, qui répond à des questions en se basant uniquement sur un document PDF (CV, rapport, note…).  
Le projet utilise **Ollama** (LLM local), **bge-m3** (embeddings multilingues) et **ChromaDB** (base vectorielle).

---

## Objectif

Ce notebook implémente un pipeline RAG complet :

1. **Chargement & découpage** du PDF en chunks (`RecursiveCharacterTextSplitter`)
2. **Vectorisation** des chunks avec `bge-m3` (Ollama)
3. **Stockage** dans ChromaDB
4. **Retrieval** des chunks pertinents
5. **Génération** de la réponse par `llama3.1` (Ollama)
6. **Évaluation** de la fidélité (*groundness*) par un LLM juge

---

## Stack technique

| Composant | Technologie |
|---|---|
| LLM | [Ollama](https://ollama.com/) — `llama3.1` |
| Embeddings | Ollama — `bge-m3` (1024 dims, multilingue) |
| Base vectorielle | ChromaDB |
| Framework | LangChain (`langchain`, `langchain-ollama`, `langchain-chroma`) |
| Environnement | Python 3.11+ avec `uv` |

---

## Prérequis

### 1. Installer Ollama

- **macOS / Linux** : https://ollama.com/download
- **Windows** : https://ollama.com/download/windows

Vérifier l'installation :
```bash
ollama --version
```

### 2. Télécharger les modèles

```bash
ollama pull llama3.1
ollama pull bge-m3
```

Vérifier :
```bash
ollama list
```

### 3. Installer `uv` (gestionnaire de paquets Python)

```bash
# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# Windows (PowerShell)
powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
```

---

## Installation du projet

### 1. Cloner le repo

```bash
git clone https://github.com/<votre-username>/RAG-test.git
cd RAG-test
```

### 2. Initialiser l'environnement

```bash
uv init
uv venv
```

### 3. Activer l'environnement virtuel

```bash
# Windows (PowerShell)
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process
.venv\Scripts\activate

# macOS / Linux
source .venv/bin/activate
```

### 4. Installer les dépendances

```bash
uv add ipykernel
uv add langchain
uv add langchain-ollama
uv add langchain-text-splitters
uv add langchain-community
uv add langchain-chroma
uv add chromadb
uv add pypdf
```

### 5. Ajouter le PDF

Créer un dossier `pdfs/` à la racine et y placer votre PDF :

```
RAG-test/
├── pdfs/
│   └── JOUKARRID MOHAMMED.pdf
├── store/                  # créé automatiquement par Chroma
├── rag.ipynb
├── README.md
└── pyproject.toml
```

### 6. Lancer Ollama

```bash
ollama serve
```
*(Laisser ce terminal ouvert, ou Ollama tourne déjà en arrière-plan sur Windows/Mac.)*

### 7. Lancer Jupyter

```bash
uv run jupyter notebook
```

Ouvrir `rag.ipynb` et exécuter les cellules **dans l'ordre**.

---

## Exemples de questions

### Questions qui donnent une réponse (extraits du CV)

- Quelles sont les compétences techniques de Mohammed Joukarrid ?
- Quel est le diplôme le plus récent ?
- Quelle est la précision du projet de reconnaissance des émotions vocales ?
- Quelles technologies ont été utilisées pour le projet de trafic aérien ?
- Quelle certification a-t-il obtenue ?

### Questions qui donnent « Je ne sais pas ! »

- Quel est le prix du Bitcoin aujourd'hui ?
- Quelle est la capitalisation boursière du Maroc en 2025 ?
- Quels sont les événements culturels dans le sud-est du Maroc ?

---

## Structure du projet

```
RAG-test/
├── pdfs/
│   └── JOUKARRID MOHAMMED.pdf     # document source
├── store/                         # base vectorielle Chroma (persistante)
├── rag.ipynb                      # notebook principal
├── README.md
├── pyproject.toml
└── .gitignore
```

---

## Points importants

- **Aucune clé API** n'est requise (tout tourne en local avec Ollama).
- Si vous changez le **modèle d'embedding**, vous **devez** changer le `collection_name` dans Chroma (`bge-m3` = 1024 dims, `nomic-embed-text` = 768 dims, etc.). Chroma refuse de mélanger deux dimensions.
- Le `persist_directory="./store"` permet de **sauvegarder** la base vectorielle : vous n'avez pas à réindexer à chaque exécution.
- Le paramètre `search_kwargs={'k': 5}` du retriever **doit** utiliser deux-points (`:`), pas une virgule — sinon `k` n'est pas défini.

---

## Dépannage

| Erreur | Cause | Solution |
|---|---|---|
| `ConnectionError: Ollama not running` | Ollama n'est pas lancé | `ollama serve` |
| `InvalidDimensionException` | Mélange de dimensions dans Chroma | Changer `collection_name` ou supprimer `./store` |
| `Model 'llama3.1' not found` | Modèle non téléchargé | `ollama pull llama3.1` |
| `ModuleNotFoundError: langchain_ollama` | Dépendance manquante | `uv add langchain-ollama` |
| `pypdf` introuvable | Dépendance manquante | `uv add pypdf` |

---

## Licence

Projet pédagogique — libre d'utilisation et de modification.

---

## Auteur

**JOUKARRID MOHAMMED**  
Master Intelligence Artificielle & Digital Computing — FST Béni Mellal  
📧 joukaridmohammed.888@gmail.com  
🔗 [LinkedIn](https://www.linkedin.com/in/joukarrid-mohammed)